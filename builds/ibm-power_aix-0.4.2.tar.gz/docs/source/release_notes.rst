.. ...........................................................................
.. © Copyright IBM Corporation 2020                                          .
.. ...........................................................................

Releases
========

Version 0.4.1
-------------
Notes
  * Initial beta release of IBM Power Systems AIX collection, referred to as power_aix

Availability
  * `GitHub`_

.. _GitHub:
   https://github.com/IBM/ansible-power-aix/releases/download/v0.4.1/ibm-power_aix-0.4.1.tar.gz

