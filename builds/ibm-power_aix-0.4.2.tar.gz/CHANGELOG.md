# Changelog

All notable changes to this project will be documented in this file.

## [Unreleased]

## [0.0.1] - 2020-02-26

### Added
- Added a changelog
- Initial Source Population (underway)

[unreleased]: https://github.com/ibm/ansible-power-aix/compare/v0.0.1...HEAD
[0.0.1]: https://github.com/ibm/ansible-power-aix/releases/tag/v0.0.1
